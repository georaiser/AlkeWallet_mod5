package com.curso04.mod5.wallet.constants;

public class Constants {

	public static final String URL = "jdbc:mysql://localhost:3306/AlkeWalletDB";
	public static final String USER = "root";
	public static final String PASSWORD = "Admin2024";
	public static final String DRIVER_MYSQL = "com.mysql.cj.jdbc.Driver";	
}
