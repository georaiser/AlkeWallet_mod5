package com.curso04.mod5.wallet.main;

public class MainTestingCode {

	public static void main(String[] args) {

/*
		Random rand = new Random();
		// Generate random integers in range
		int accountNumber = rand.nextInt(10000, 99999);

		Account account = new Account(accountNumber, "Antonio", 500);
		System.out.println(account.getAccountBalance());

		// ACCOUNTSERVICES
		// account insert into dataBase (DAO) through accountServices
		AccountServices accountServices = new AccountServices();
		boolean insertion = accountServices.insertAccount(account);
		System.out.println(insertion);

		// return list Accounts
		AccountServices accountServices2 = new AccountServices();
		List<Account> list2 = accountServices2.listAccount();
		for (Account listAcount : list2) {
			System.out.println(listAcount.getAccountHolder());
		}

		// searching by Account Name
		AccountServices accountServices3 = new AccountServices();
		List<Account> list3 = accountServices3.searchAccountHolder("Antonio");
		for (Account listAcount : list3) {
			System.out.println(listAcount.getAccountNumber());
		}

		// searching by Account number ///////
		AccountServices accountServices4 = new AccountServices();
		Account account4 = accountServices4.searchAccountNumber(68748);
		System.out.println(account4.getAccountHolder());

		//////// update account process
		// get account to update
		AccountServices accountServices5 = new AccountServices();
		Account account5 = accountServices5.searchAccountNumber(68748);

		// change values
		account5.setAccountBalance(259875);
		account5.setAccountHolder("Oscar");

		// update account
		boolean completedUpdate = accountServices5.updateAccount(account5);
		System.out.println(completedUpdate);

		// delete account
		// AccountServices accountServices7 = new AccountServices();
		// boolean isDeleted = accountServices7.deleteAccount(96167);
		// System.out.println(isDeleted);
		
		
		// first create account to create customer (foreign key)
		Account account = new Account(10006, "Antonio", 500);
		AccountServices accountServices = new AccountServices();
		boolean insertion = accountServices.insertAccount(account);
		System.out.println(insertion);
		
		Customer customer = new Customer("Antonio", 10006);
		System.out.println(customer.getName());
		
		CustomerServices customerServices = new CustomerServices();
		customerServices.insertCustomer(customer);
		
*/		 
		
		
	}

}
